//
//  TallyGoKit.h
//  TallyGoKit
//
//  Created by Anthony Picciano on 8/1/16.
//  Copyright © 2016 TallyGo. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TallyGoKit.
FOUNDATION_EXPORT double TallyGoKitVersionNumber;

//! Project version string for TallyGoKit.
FOUNDATION_EXPORT const unsigned char TallyGoKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TallyGoKit/PublicHeader.h>


